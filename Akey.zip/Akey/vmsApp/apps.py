import imp
from django.apps import AppConfig


class vmsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vmsApp'
